package com.ubaya.cerbungnmp

data class Users(val username:String, val password:String, val url:String)
