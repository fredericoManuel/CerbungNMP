package com.ubaya.cerbungnmp

object Global {
    val ceritaBersambung = arrayListOf(
        Cerbung(1,"Cerita di Gua Hantu", "Arryan", "Disuatu hari di sebuah gua hantu, ada seorang bernama Budi sedang mencari sebuah buah iblis", "https://akcdn.detik.net.id/community/media/visual/2019/10/31/5e38a4e1-8395-44e9-9ca1-19a0de5332eb_43.jpeg?w=250&q=",6,1, "misteri", "Pada suatu hari yang cerah, di sebuah hutan lebat yang penuh dengan misteri terletak sebuah gua tua yang terkenal dengan julukan \"Gua Hantu\". Gua ini menjadi terkenal karena kabar-kabar tentang kejadian-kejadian aneh yang terjadi di dalamnya. Namun, cerita itu tidak membuat Budi, seorang petualang yang penuh dengan semangat dan rasa ingin tahu, merasa takut. Dia telah mendengar legenda mengenai buah iblis yang dikatakan memiliki kekuatan luar biasa, dan kabarnya buah itu tersimpan di dalam gua ini. Itulah sebabnya dia memutuskan untuk mencari buah iblis tersebut.\n" +
                "\n" +
                "Budi adalah seorang pria yang berani dan bersemangat. Dia telah menjelajahi banyak tempat berbahaya sepanjang hidupnya dan tidak pernah takut dengan hal-hal supernatural. Bersenjatakan peta yang sudah dia peroleh dari seorang petualang yang pernah mencoba mengejar buah iblis tersebut, Budi memasuki gua dengan tekad yang kuat.\n" +
                "\n" +
                "Saat masuk ke dalam gua, suasana menjadi semakin gelap dan mencekam. Cahaya matahari tidak lagi dapat menembus ke dalam gua, dan Budi mengandalkan senter yang dia bawa. Dia merasa seperti tengah berada di dunia yang berbeda, di mana bayangan dan suara-suara misterius mengelilinginya.", "12 Oktober 2023", true),
        Cerbung(2,"Misteri Kota Tersembunyi", "Laila", "Rina dan teman-temannya menemukan peta misterius yang mengarah ke kota yang hilang di tengah hutan", "https://www.aljazeera.com/wp-content/uploads/2022/02/chernobyl.jpg?resize=1200%2C630",5,1, "misteri", "Rina dan teman-temannya adalah sekelompok anak muda yang selalu haus petualangan. Mereka tinggal di sebuah desa kecil yang dikelilingi oleh hutan lebat. Hutan itu sendiri memiliki banyak rahasia, cerita mistis, dan legenda. Salah satu legenda yang paling menarik adalah tentang \"Kota yang Hilang,\" sebuah kota kuno yang konon pernah ada di tengah hutan, tetapi sekarang telah lenyap tanpa jejak.\n" +
                "\n" +
                "Suatu hari, saat mereka sedang menjelajahi hutan untuk bermain, Rina menemukan sesuatu yang berkilauan di antara rerimbunan daun. Ternyata itu adalah selembar peta kuno yang sangat usang. Peta tersebut menunjukkan rute yang mengarah ke \"Kota yang Hilang.\" Rina dan teman-temannya tidak bisa menyembunyikan kegembiraan mereka saat menemukan peta misterius tersebut.", "10 September 2023", false),
        Cerbung(3, "Pulau Terlarang", "Danis", "Sebuah pulau misterius muncul dari tengah lautan. Kevin memutuskan untuk menyelidiki rahasia di balik pulau tersebut", "https://asset.kompas.com/crops/U2OWJNePo0-uAHJjtQYjZdh1Y0M=/120x80:1080x720/750x500/data/photo/2020/03/21/5e75693662a94.jpg",2,1, "misteri", "Pada suatu hari yang cerah, peristiwa luar biasa terjadi di tengah lautan lepas. Sebuah pulau misterius, yang sebelumnya tidak pernah ada di peta manapun, muncul begitu saja di tengah-tengah lautan yang luas. Pulau itu diapit oleh kabut tebal yang membuatnya terlihat seperti pulau yang benar-benar muncul dari dunia lain. Berita tentang penampakan pulau ini dengan cepat menyebar ke seluruh dunia, menciptakan kegembiraan dan kebingungan di kalangan ilmuwan, penjelajah, dan penasaran.\n" +
                "\n" +
                "Salah satu orang yang terpesona oleh munculnya pulau misterius ini adalah Kevin, seorang penjelajah dan ilmuwan kelautan yang selalu haus akan petualangan. Sejak kecil, ia selalu bermimpi tentang mengeksplorasi tempat-tempat baru yang tidak pernah dijangkau oleh manusia sebelumnya. Munculnya pulau ini adalah kesempatan yang sangat langka, dan Kevin tidak ingin melepaskannya begitu saja.", "11 Oktober 2023", true))

    val genre = arrayOf(
        Genre(1, "Action"),
        Genre(2, "Anime"),
        Genre(3, "Comedy"),
        Genre(4, "Crime"),
        Genre(5, "Drama"),
        Genre(6, "History"),
        Genre(7, "Horror"),
        Genre(8, "Kids"),
        Genre(9, "Romance"),
        Genre(10, "Sci-Fi & Fantasy"),
        Genre(11, "Thriller")
    )

    val user = arrayListOf(
        Users("Marcel", "160721044", "https://my.ubaya.ac.id/img/mhs/160721044_l.jpg"),
        Users("Arryan", "160721049", "https://my.ubaya.ac.id/img/mhs/160721049_l.jpg"),
        Users("Frederico","160721056", "https://my.ubaya.ac.id/img/mhs/160721056_l.jpg")
    )
}